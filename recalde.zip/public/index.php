<?php

require_once dirname(__DIR__) . '/index.php';
