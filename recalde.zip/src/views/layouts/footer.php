    <!--
    
    <footer>
        <p>&copy; <?php echo date("Y"); ?> RECALDE. Todos los derechos reservados.</p>
    </footer>

    -->
    <script src="<?= htmlspecialchars((defined('BASE_URL') ? BASE_URL : ''), ENT_QUOTES, 'UTF-8') ?>/public/js/dashboardcontrol.js"></script>
</body>
</html>
