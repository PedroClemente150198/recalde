<?php

require_once BASE_PATH.'/src/views/layouts/header.php';
require_once BASE_PATH.'/src/views/layouts/footer.php';
?>
